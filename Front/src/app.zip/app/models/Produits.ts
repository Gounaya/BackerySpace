export class Produits {

  idProduit: number;
  designation: string;
  description: string;
  prix: number;
  selected: boolean; // For product Hero
  photo: string;
  quantite: number;

}
